/*
 * Steganography utility to hide messages into cover files
 * Author: Team Number 10 
 * Copyright (c) Team Number 10
 */

package com.mystego.desktop.plugin.dctlsb;

import com.mystego.desktop.MyStegoException;

/**
 * Class to store error codes for DCT LSB plugin
 */
public class DctLSBErrors {
    /**
     * Error Code - Error while reading image data
     */
    public static final int ERR_IMAGE_DATA_READ = 1;

    /**
     * Error Code - Image size insufficient for data
     */
    public static final int IMAGE_SIZE_INSUFFICIENT = 2;

    /**
     * Initialize the error code - message key map
     */
    public static void init() {
        MyStegoException.addErrorCode(DctLSBPlugin.NAMESPACE, ERR_IMAGE_DATA_READ, "err.image.read");
        MyStegoException.addErrorCode(DctLSBPlugin.NAMESPACE, IMAGE_SIZE_INSUFFICIENT, "err.image.insufficientSize");
    }
}
