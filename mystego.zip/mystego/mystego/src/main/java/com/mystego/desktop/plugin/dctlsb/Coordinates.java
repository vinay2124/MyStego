/*
 * Steganography utility to hide messages into cover files
 * Author: Team Number 10 
 * Copyright (c) Team Number 10
 */

package com.mystego.desktop.plugin.dctlsb;

import java.util.HashMap;
import java.util.Map;

/**
 * Class for storing co-ordinate hits
 */
public class Coordinates {
    /**
     * Maximum size of the coordinate space
     */
    private final int size;

    /**
     * Map to store the hits
     */
    private final Map<String, String> map = new HashMap<>();

    /**
     * Default constructor
     *
     * @param size Maximum size of the coordinate space
     */
    public Coordinates(int size) {
        this.size = size;
    }

    /**
     * Add coordinate to the space. If already hit, it returns false
     *
     * @param x X-axis coordinate
     * @param y Y-axis coordinate
     * @return False, if coordinate already hit
     */
    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    public boolean add(int x, int y) {
        if (this.map.size() >= this.size) {
            throw new IllegalArgumentException("Exhausted the coordinate space");
        }

        String key = x + "," + y;
        if (this.map.containsKey(key)) {
            return false;
        } else {
            this.map.put(key, key);
            return true;
        }
    }
}
