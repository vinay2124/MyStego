/*
 * Steganography utility to hide messages into cover files
 * Author: Team Number 10 
 * Copyright (c) Team Number 10
 */

package com.mystego.desktop.plugin.dwtkim;

import com.mystego.desktop.MyStegoException;

/**
 * Class to store error codes for DWT Kim plugin
 */
public class DWTKimErrors {
    /**
     * Error Code - No cover file given
     */
    public static final int ERR_NO_COVER_FILE = 1;

    /**
     * Error Code - Image decomposition levels are not enough
     */
    public static final int ERR_DECOMP_LEVEL_NOT_ENOUGH = 2;

    /**
     * Error Code - Invalid signature file provided
     */
    public static final int ERR_SIG_NOT_VALID = 3;

    /**
     * Error Code - file size not enough to embed watermark
     */
    public static final int ERR_FILE_TOO_SMALL = 3;

    /**
     * Initialize the error code - message key map
     */
    public static void init() {
        MyStegoException.addErrorCode(DWTKimPlugin.NAMESPACE, ERR_NO_COVER_FILE, "err.cover.missing");
        MyStegoException.addErrorCode(DWTKimPlugin.NAMESPACE, ERR_DECOMP_LEVEL_NOT_ENOUGH, "err.image.decompLevel.notEnough");
        MyStegoException.addErrorCode(DWTKimPlugin.NAMESPACE, ERR_SIG_NOT_VALID, "err.signature.invalid");
    }
}
