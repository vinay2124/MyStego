/*
 * Steganography utility to hide messages into cover files
 * Author: Team Number 10 
 * Copyright (c) Team Number 10
 */

package com.mystego.desktop;

import java.util.ArrayList;
import java.util.List;

/**
 * Custom exception class to store multiple errors
 */
public class MyStegoBulkException extends Exception {

    /**
     * List of keys for the exception
     */
    private final List<String> keys = new ArrayList<>();
    /**
     * List of exceptions
     */
    private final List<MyStegoException> exceptions = new ArrayList<>();

    /**
     * Add an exception to this bulk list
     *
     * @param key Key for the exception (e.g. filename)
     * @param e   Exception to be added
     */
    public void add(String key, MyStegoException e) {
        keys.add(key);
        exceptions.add(e);
    }

    /**
     * Return the current list of keys
     */
    public List<String> getKeys() {
        return keys;
    }

    /**
     * Return the current list of exceptions
     */
    public List<MyStegoException> getExceptions() {
        return exceptions;
    }

    /**
     * Throw this exception if list is not empty
     */
    public void throwIfRequired() throws MyStegoBulkException {
        if (!exceptions.isEmpty()) {
            throw this;
        }
    }

}
